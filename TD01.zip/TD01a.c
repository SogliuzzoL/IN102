/* Loris SOGLIUZZO */
#include <stdio.h>

int main()
{
    printf("Mon\npremier\nprogramme\n");
    return 0;
}

/* 
Question 2: gcc thefirstone.c
Question 3: a.out
Question 4: ./a.out
Question 5: gcc thefirstone.c -o monprogramme
*/